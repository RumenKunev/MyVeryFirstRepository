﻿
using System;

class FibonaciNumbers
{
    static void Main()
    {
        Console.WriteLine("Please, enter the number of the sequence: ");
        string str = Console.ReadLine();
        int sequenceNumbers = int.Parse(str);
        
        int firstNum = 0;
        int secondNum = 1;
        int totalSum = 1;

        Console.Write("{0}, {1}", firstNum, secondNum);
        for (int i = 0; i < sequenceNumbers; i++)
        {
            int sumNextMember = firstNum + secondNum;
            firstNum = secondNum;
            secondNum = sumNextMember;
            Console.Write(" ,{0}",sumNextMember);
            totalSum += sumNextMember;
        }
        Console.WriteLine();
        Console.WriteLine("The sum of the members is:{0}",totalSum);
    }




}
