﻿using System;

class Matrix
{

    static void Main()
    {
        Console.Write("Please enter a number: ");
        int inputNumber = int.Parse(Console.ReadLine());

        int[,] matrix = new int[inputNumber, inputNumber];
        
        for (int row = 0; row < inputNumber; row++)
        {
            for (int col = 0; col < inputNumber; col++)
            {
                matrix[row, col] = inputNumber + inputNumber - row;
                Console.Write(matrix[row, col]);
            }
           
            Console.WriteLine();
        }

        //for (int row = 0; row < matrix.GetLength(0); row++)
        //{
        //    for (int col = 0; col < matrix.GetLength(1); col++)
        //    {
        //        Console.Write(" " + matrix[row, col]);
        //    }
        //    Console.WriteLine();
        //}
    }
}
