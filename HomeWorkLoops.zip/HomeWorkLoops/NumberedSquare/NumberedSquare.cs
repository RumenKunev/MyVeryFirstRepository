﻿using System;

class NumberedSquare
{
    static void Main(string[] args)
    {
        Console.Write("please enter a number: ");
        string inputData = Console.ReadLine();
        int inputNumber = int.Parse(inputData);

        for (int row = 1; row <= inputNumber; row++)
        {
            for (int col = row; col <= inputNumber+row-1; col++)
            {
                Console.Write(col);
            }
            Console.WriteLine();
        }
    }
}
