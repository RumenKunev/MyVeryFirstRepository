﻿using System;
using System.Numerics;

class Zeroes
{
    static void Main()
    {
        Console.WriteLine("Please enter anumber:");
        int N = int.Parse(Console.ReadLine());
        BigInteger factorial = 1;
        int counter = 0;

        for (int i = 1; i <= N; i++)
        {
            factorial *= i;
        }
        Console.WriteLine(factorial);

        while (factorial >= 0)
        {
            if (factorial % 10 == 0)
            {
                counter++;
                factorial /= 10;
            }
            else
            {
                break;
            }
        }
        Console.WriteLine("The factorial has {0} zeroes!", counter);
    }
}
